# load the package
library("U.PhyloMaker")

# input the sample species list, the megatree and genus-family relationship files
sp.list <- read.csv("amphibian_sample_species_list.csv")
megatree <-read.tree("amphibian_megatree.tre")
gen.list <- read.csv("amphibian_genus_list.csv")

# generate a phylogeny for the sample species list
result <- phylo.maker(sp.list, megatree, gen.list, nodes.type = 1, scenario = 3)
write.tree(result$phylo, "output_tree.tre")
write.csv(result$sp.list, "output_splist.csv")
