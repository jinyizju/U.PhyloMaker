
### R script to use U.PhyloMaker to generate multiple phylogenetic trees based on multiple megatrees,
### using a fish species list as an example and setting the number of phylogenetic trees to 10 (i.e.,
### randomly select 10 megatrees from the pool of the megatrees available at the folder).

# Load the package
library("U.PhyloMaker")

# Set the working directory, where the data and megatree(s) are stored. The following command
# is not required if the user creates a new folder for the project and places all relevant files
# in the folder.
# setwd("D:/full_trees_fish") 

# Import all tre files in the working directory into R
filenames <- list.files(pattern="*.tre", full.names=TRUE)
megatrees <- lapply(filenames, read.tree) # import the sample species list

# Input the sample species list
sp.list <- read.csv("Sample_species_list - fish - N Am.csv")     # import the sample species list
gen.list <- read.csv("Fish_genus_list.csv")   # import the genus-family relationship file

# Sample a certain number of megatrees in the imported megatrees.
N <- 10   # the number of megatrees to sample
result <- list()
n <- sample(1:length(megatrees), N)
for (i in 1:N)
{
tn <- megatrees[[n[i]]]
result <- phylo.maker(sp.list, tn, gen.list, nodes.type = 1, scenario = 3)
x <- gsub("./", "", filenames[n[i]])
#x <- gsub(".tre", "", x)
write.tree(result$phylo, paste("output_tree_based_on_", x, sep = ""))
write.csv(result$sp.list,paste("output_sp.list_based_on_", x, ".csv", sep = ""))
}